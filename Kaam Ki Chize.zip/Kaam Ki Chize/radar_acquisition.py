import argparse
import csv
import datetime
import os
import threading
import time
from typing import Callable, Optional

import numpy as np
import numpy.matlib  # noqa: F401  (retained for compatibility with original script)
import serial
from mmWave import vitalsign
from serial import Serial

DEFAULT_COM_PORTS = ["COM7"]

class RadarError(Exception):
    """Custom exception for radar acquisition errors."""


def _open_radar_port(preferred_port: Optional[str] = None) -> Serial:
    """Try to open the radar serial port."""
    candidate_ports = []
    if preferred_port:
        candidate_ports.append(preferred_port)
    candidate_ports.extend([port for port in DEFAULT_COM_PORTS if port not in candidate_ports])

    last_error = None
    for port_name in candidate_ports:
        try:
            port = serial.Serial(port_name, baudrate=921600, timeout=0.5)
            return port
        except Exception as exc:  # pragma: no cover - hardware dependent
            last_error = exc
            continue

    raise RadarError(f"Could not open radar serial port. Last error: {last_error}")


def run_radar(
    duration: float,
    output_path: Optional[str] = None,
    preferred_port: Optional[str] = None,
    port: Optional[Serial] = None,
    vts: Optional[vitalsign.VitalSign] = None,
    data_callback: Optional[Callable[[float, float], None]] = None,
    stop_event: Optional[threading.Event] = None,
) -> str:
    """
    Run the radar acquisition loop for the given duration and save to CSV.

    Parameters
    ----------
    duration : float
        Recording duration in seconds.
    output_path : str, optional
        Destination CSV path. Defaults to a timestamped file in CWD.
    preferred_port : str, optional
        Serial port name to try first when creating a new connection.
    port : serial.Serial, optional
        Pre-initialized serial port to reuse. The caller remains responsible for closing it.
    vts : vitalsign.VitalSign, optional
        Pre-initialized vital sign interface to reuse.
    data_callback : callable, optional
        Function invoked with (elapsed_time, value) for each recorded sample.
    stop_event : threading.Event, optional
        External stop signal. When set, acquisition stops gracefully.

    Returns
    -------
    str
        The path to the CSV file containing the recorded data.
    """
    if duration <= 0:
        raise ValueError("Duration must be positive.")

    created_port = False
    created_vts = False
    if port is None or not port.is_open:
        port = _open_radar_port(preferred_port)
        created_port = True

    if vts is None:
        vts = vitalsign.VitalSign(port)
        created_vts = True

    port.flushInput()

    if output_path is None:
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = os.path.abspath(f"radar_data_{timestamp}.csv")

    stop_event = stop_event or threading.Event()

    start_time = time.time()
    rp7 = np.zeros(23)

    try:
        with open(output_path, "w", newline="") as csvfile:
            writer = csv.writer(
                csvfile,
                delimiter=",",
                quotechar='"',
                quoting=csv.QUOTE_NONE,
                escapechar="\\",
            )
            writer.writerow(["time", "data"])

            while True:
                if stop_event.is_set():
                    break

                elapsed = time.time() - start_time
                if elapsed >= duration:
                    break

                dck, vd, rangeBuf = vts.tlvRead(False)
                if not dck:
                    continue

                rp7 = [
                    np.sqrt(rangeBuf[i * 2] ** 2 + rangeBuf[i * 2 + 1] ** 2)
                    for i in range(min(23, len(rangeBuf) // 2))
                ]

                writer.writerow([elapsed, vd.unwrapPhasePeak_mm])

                if data_callback:
                    data_callback(elapsed, vd.unwrapPhasePeak_mm)

    finally:
        if created_vts and hasattr(vts, "close"):  # pragma: no cover - depends on implementation
            try:
                vts.close()
            except Exception:
                pass
        if created_port and port and port.is_open:
            port.close()

    return output_path


def main():
    parser = argparse.ArgumentParser(description="Run radar acquisition and save to CSV.")
    parser.add_argument(
        "--duration",
        type=float,
        required=True,
        help="Recording duration in seconds.",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output CSV file path. Defaults to timestamped file.",
    )
    parser.add_argument(
        "--port",
        type=str,
        default=None,
        help="Preferred serial port (e.g., COM20).",
    )
    args = parser.parse_args()

    stop_event = threading.Event()

    try:
        output_path = run_radar(
            duration=args.duration,
            output_path=args.output,
            preferred_port=args.port,
            stop_event=stop_event,
        )
        print(f"Radar data saved to {output_path}")
    except Exception as exc:
        print(f"Radar acquisition failed: {exc}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()


    