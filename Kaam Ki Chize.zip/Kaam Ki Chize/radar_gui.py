import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import time
import os
import subprocess
import sys
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
import pandas as pd

# Import your radar module
try:
    from radar_acquisition import run_radar, RadarError
except ImportError:
    print("Note: radar_acquisition module not found. Using placeholder functions.")


class RadarGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Radar Data Acquisition System - Sleep Quality Analysis")
        self.root.geometry("1100x900")
        
        # Variables
        self.recording = False
        self.stop_event = None
        self.record_thread = None
        self.data_buffer = []  # Store (time, value) pairs for plotting
        self.current_output_path = None
        self.processing_thread = None
        self.last_results = None
        self.notebook_path = "ISProject_final_integration.ipynb"
        
        # Setup GUI
        self.setup_styles()
        self.create_widgets()
        self.setup_plot()
        
    def setup_styles(self):
        """Configure ttk styles"""
        style = ttk.Style()
        style.theme_use('clam')
        
        style.configure("Start.TButton", foreground="green", font=("Arial", 10, "bold"))
        style.configure("Stop.TButton", foreground="red", font=("Arial", 10, "bold"))
        style.configure("Status.TLabel", font=("Arial", 10))
        style.configure("green.Horizontal.TProgressbar", background='green', troughcolor='lightgray')
        style.configure("yellow.Horizontal.TProgressbar", background='orange', troughcolor='lightgray')
        style.configure("red.Horizontal.TProgressbar", background='red', troughcolor='lightgray')
        
    def create_widgets(self):
        """Create all GUI widgets"""
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=10, pady=10)
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        
        # Tab 1: Recording
        self.recording_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.recording_tab, text="Recording")
        
        # Tab 2: Results
        self.results_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.results_tab, text="Sleep Quality Results")
        
        self.setup_recording_tab()
        self.setup_results_tab()
        
    def setup_recording_tab(self):
        """Setup the recording tab widgets"""
        main_frame = ttk.Frame(self.recording_tab, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.recording_tab.columnconfigure(0, weight=1)
        self.recording_tab.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        
        # Configuration Frame
        config_frame = ttk.LabelFrame(main_frame, text="Configuration", padding="10")
        config_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=5)
        config_frame.columnconfigure(1, weight=1)
        
        # Duration
        ttk.Label(config_frame, text="Recording Duration (seconds):").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.duration_var = tk.DoubleVar(value=30.0)
        duration_spinbox = ttk.Spinbox(config_frame, from_=1.0, to=3600.0, textvariable=self.duration_var, width=15)
        duration_spinbox.grid(row=0, column=1, sticky=tk.W, padx=5, pady=5)
        ttk.Label(config_frame, text="seconds").grid(row=0, column=2, sticky=tk.W, padx=5)
        
        # Serial Port
        ttk.Label(config_frame, text="Serial Port:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        self.port_var = tk.StringVar(value="COM7")
        port_entry = ttk.Entry(config_frame, textvariable=self.port_var, width=15)
        port_entry.grid(row=1, column=1, sticky=tk.W, padx=5, pady=5)
        ttk.Label(config_frame, text="(e.g., COM7, COM20, /dev/ttyUSB0)").grid(row=1, column=2, sticky=tk.W, padx=5)
        
        # Output File
        ttk.Label(config_frame, text="Output File:").grid(row=2, column=0, sticky=tk.W, padx=5, pady=5)
        self.output_path_var = tk.StringVar()
        output_frame = ttk.Frame(config_frame)
        output_frame.grid(row=2, column=1, columnspan=2, sticky=(tk.W, tk.E))
        output_frame.columnconfigure(0, weight=1)
        
        ttk.Entry(output_frame, textvariable=self.output_path_var, width=40).grid(row=0, column=0, sticky=(tk.W, tk.E), padx=(0, 5))
        ttk.Button(output_frame, text="Browse", command=self.browse_output_file).grid(row=0, column=1)
        
        # Control Buttons
        control_frame = ttk.Frame(main_frame)
        control_frame.grid(row=1, column=0, pady=20)
        
        self.start_button = ttk.Button(control_frame, text="▶ Start Recording", command=self.start_recording, style="Start.TButton", width=20)
        self.start_button.grid(row=0, column=0, padx=10)
        
        self.stop_button = ttk.Button(control_frame, text="■ Stop Recording", command=self.stop_recording, style="Stop.TButton", width=20, state="disabled")
        self.stop_button.grid(row=0, column=1, padx=10)
        
        # Status Frame
        status_frame = ttk.LabelFrame(main_frame, text="Status", padding="10")
        status_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=5)
        
        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(status_frame, textvariable=self.status_var, style="Status.TLabel").grid(row=0, column=0, sticky=tk.W)
        
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(status_frame, variable=self.progress_var, maximum=100, length=300)
        self.progress_bar.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=5)
        
        # Real-time Plot
        plot_frame = ttk.LabelFrame(main_frame, text="Real-time Data", padding="10")
        plot_frame.grid(row=3, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=10)
        plot_frame.columnconfigure(0, weight=1)
        plot_frame.rowconfigure(0, weight=1)
        
        self.fig, self.ax = plt.subplots(figsize=(8, 4))
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        self.ax.set_xlabel("Time (s)")
        self.ax.set_ylabel("Phase (mm)")
        self.ax.set_title("Real-time Phase Data")
        self.ax.grid(True, alpha=0.3)
        self.line, = self.ax.plot([], [], 'b-', linewidth=1)
        
        # Info Frame
        info_frame = ttk.LabelFrame(main_frame, text="Recording Information", padding="10")
        info_frame.grid(row=4, column=0, sticky=(tk.W, tk.E), pady=5)
        
        self.info_text = tk.Text(info_frame, height=5, width=70, wrap=tk.WORD)
        self.info_text.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        scrollbar = ttk.Scrollbar(info_frame, orient="vertical", command=self.info_text.yview)
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        self.info_text.configure(yscrollcommand=scrollbar.set)
        
        main_frame.rowconfigure(3, weight=1)
        
    def setup_results_tab(self):
        """Setup the results tab with sleep quality scores"""
        results_frame = ttk.Frame(self.results_tab, padding="20")
        results_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.results_tab.columnconfigure(0, weight=1)
        self.results_tab.rowconfigure(0, weight=1)
        results_frame.columnconfigure(0, weight=1)
        
        # Title
        title_label = ttk.Label(results_frame, text="Sleep Quality Analysis Results", font=("Arial", 18, "bold"))
        title_label.grid(row=0, column=0, pady=(0, 20))
        
        # Overall Score Frame
        overall_frame = ttk.LabelFrame(results_frame, text="Overall Sleep Quality", padding="15")
        overall_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=10)
        overall_frame.columnconfigure(0, weight=1)
        
        self.overall_score_var = tk.StringVar(value="--")
        self.overall_score_label = ttk.Label(overall_frame, textvariable=self.overall_score_var, font=("Arial", 36, "bold"))
        self.overall_score_label.grid(row=0, column=0, pady=10)
        
        self.overall_comment_var = tk.StringVar(value="No data processed yet")
        ttk.Label(overall_frame, textvariable=self.overall_comment_var, font=("Arial", 12)).grid(row=1, column=0)
        
        # Individual Scores Frame
        scores_frame = ttk.LabelFrame(results_frame, text="Detailed Scores", padding="15")
        scores_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=10)
        scores_frame.columnconfigure(1, weight=1)
        
        # Create labels for each score
        self.score_labels = {}
        self.score_progress = {}
        
        scores_list = [
            "Sleep Duration Score",
            "Sleep Efficiency Score", 
            "Deep Sleep Score",
            "REM Sleep Score",
            "HRV Score"
        ]
        
        for i, score_name in enumerate(scores_list):
            # Score name
            ttk.Label(scores_frame, text=f"{score_name}:", font=("Arial", 11, "bold")).grid(row=i, column=0, sticky=tk.W, pady=10, padx=10)
            
            # Score value
            self.score_labels[score_name] = ttk.Label(scores_frame, text="--", font=("Arial", 11))
            self.score_labels[score_name].grid(row=i, column=1, sticky=tk.W, pady=10, padx=10)
            
            # Progress bar
            self.score_progress[score_name] = ttk.Progressbar(scores_frame, length=300, mode='determinate', maximum=100)
            self.score_progress[score_name].grid(row=i, column=2, sticky=tk.W, pady=10, padx=10)
        
        # Control Buttons
        button_frame = ttk.Frame(results_frame)
        button_frame.grid(row=3, column=0, pady=20)
        
        self.process_button = ttk.Button(button_frame, text="Process Last Recording", command=self.process_last_recording, width=20)
        self.process_button.grid(row=0, column=0, padx=10)
        
        self.clear_button = ttk.Button(button_frame, text="Clear Results", command=self.clear_results, width=20)
        self.clear_button.grid(row=0, column=1, padx=10)
        
        # Output Text
        output_frame = ttk.LabelFrame(results_frame, text="Processing Output", padding="10")
        output_frame.grid(row=4, column=0, sticky=(tk.W, tk.E), pady=10)
        
        self.output_text = tk.Text(output_frame, height=8, width=80, wrap=tk.WORD)
        self.output_text.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        output_scrollbar = ttk.Scrollbar(output_frame, orient="vertical", command=self.output_text.yview)
        output_scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        self.output_text.configure(yscrollcommand=output_scrollbar.set)
        
        scores_frame.rowconfigure(len(scores_list), weight=1)
        
    def clear_results(self):
        """Clear all displayed results"""
        for score_name in self.score_labels:
            self.score_labels[score_name].config(text="--")
            self.score_progress[score_name]['value'] = 0
            self.score_progress[score_name].style = 'red.Horizontal.TProgressbar'
        
        self.overall_score_var.set("--")
        self.overall_comment_var.set("No data processed yet")
        self.last_results = None
        
    def display_scores(self, results):
        """Display the sleep quality scores"""
        # Store results
        self.last_results = results
        
        # Calculate overall score (average of all scores)
        overall = 0
        count = 0
        
        for score_name, score_value in results.items():
            if score_name in self.score_labels:
                # Update label and progress bar
                self.score_labels[score_name].config(text=score_value)
                
                # Extract numeric value
                try:
                    numeric_value = float(score_value.rstrip('%'))
                    self.score_progress[score_name]['value'] = numeric_value
                    
                    # Set color based on value
                    if numeric_value >= 80:
                        self.score_progress[score_name].style = 'green.Horizontal.TProgressbar'
                    elif numeric_value >= 60:
                        self.score_progress[score_name].style = 'yellow.Horizontal.TProgressbar'
                    else:
                        self.score_progress[score_name].style = 'red.Horizontal.TProgressbar'
                    
                    overall += numeric_value
                    count += 1
                except:
                    pass
        
        # Calculate and display overall score
        if count > 0:
            overall_score = overall / count
            self.overall_score_var.set(f"{overall_score:.1f}%")
            
            # Add comment based on overall score
            if overall_score >= 85:
                comment = "Excellent! Your sleep quality is outstanding!"
            elif overall_score >= 70:
                comment = "Good! Your sleep quality is above average."
            elif overall_score >= 50:
                comment = "Fair. There's room for improvement."
            else:
                comment = "Poor. Consider improving your sleep habits."
            
            self.overall_comment_var.set(comment)
        
        # Switch to results tab
        self.notebook.select(self.results_tab)
        
    def setup_plot(self):
        """Initialize the plot"""
        self.ax.set_xlim(0, 10)
        self.ax.set_ylim(-10, 10)
        self.canvas.draw()
        
    def browse_output_file(self):
        """Browse for output file location"""
        initial_dir = os.path.expanduser("~")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        default_filename = f"radar_data_{timestamp}.csv"
        
        filename = filedialog.asksaveasfilename(
            title="Save CSV File",
            initialdir=initial_dir,
            initialfile=default_filename,
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        
        if filename:
            self.output_path_var.set(filename)
            
    def update_plot(self):
        """Update the real-time plot"""
        if self.data_buffer:
            times = [d[0] for d in self.data_buffer]
            values = [d[1] for d in self.data_buffer]
            
            self.line.set_data(times, values)
            
            if times:
                self.ax.set_xlim(max(0, times[-1] - 10), max(10, times[-1] + 1))
                
                if values:
                    value_range = max(values) - min(values)
                    if value_range > 0:
                        margin = value_range * 0.1
                        self.ax.set_ylim(min(values) - margin, max(values) + margin)
                    else:
                        self.ax.set_ylim(values[0] - 1, values[0] + 1)
            
            self.canvas.draw_idle()
        
        if self.recording:
            self.root.after(100, self.update_plot)
            
    def data_callback(self, elapsed_time, value):
        """Callback function for radar data"""
        if self.recording:
            self.data_buffer.append((elapsed_time, value))
            
            if len(self.data_buffer) > 1000:
                self.data_buffer = self.data_buffer[-1000:]
            
            if self.duration_var.get() > 0:
                progress = (elapsed_time / self.duration_var.get()) * 100
                self.progress_var.set(progress)
            
            self.status_var.set(f"Recording: {elapsed_time:.1f}s / {self.duration_var.get():.1f}s")
            
    def start_recording_thread(self, duration, output_path, port):
        """Run radar acquisition in a separate thread"""
        try:
            output_path = run_radar(
                duration=duration,
                output_path=output_path,
                preferred_port=port,
                data_callback=self.data_callback,
                stop_event=self.stop_event
            )
            
            if not self.stop_event.is_set():
                self.root.after(0, self.recording_completed, output_path)
            else:
                self.root.after(0, self.recording_stopped, output_path)
                
        except Exception as e:
            self.root.after(0, self.recording_error, str(e))
    
    def process_csv_directly(self, csv_file_path):
        """Directly process the CSV file and compute sleep scores"""
        try:
            self.output_text.insert(tk.END, f"\nProcessing file: {csv_file_path}\n")
            self.output_text.see(tk.END)
            
            # Read CSV file
            df = pd.read_csv(csv_file_path)
            self.output_text.insert(tk.END, f"Loaded {len(df)} samples\n")
            
            # Get phase data
            if 'data' in df.columns:
                phase_data = df['data'].values
            elif 'unwrapPhasePeak_mm' in df.columns:
                phase_data = df['unwrapPhasePeak_mm'].values
            else:
                # Try first numeric column
                numeric_cols = df.select_dtypes(include=[np.number]).columns
                if len(numeric_cols) > 0:
                    phase_data = df[numeric_cols[0]].values
                else:
                    raise ValueError("No numeric data found in CSV")
            
            self.output_text.insert(tk.END, f"Processing {len(phase_data)} data points...\n")
            
            # Calculate sleep scores
            results = self.calculate_sleep_scores(phase_data)
            
            # Display results
            self.output_text.insert(tk.END, "\n=== Calculated Sleep Scores ===\n")
            for key, value in results.items():
                self.output_text.insert(tk.END, f"{key}: {value}\n")
            
            return results
            
        except Exception as e:
            self.output_text.insert(tk.END, f"Error processing file: {str(e)}\n")
            import traceback
            self.output_text.insert(tk.END, traceback.format_exc())
            return None
    
    def calculate_sleep_scores(self, phase_data):
        """Calculate sleep quality scores from phase data"""
        # Basic statistics
        mean_phase = np.mean(phase_data)
        std_phase = np.std(phase_data)
        
        # Calculate movement index (standard deviation of differences)
        movement = np.std(np.diff(phase_data)) if len(phase_data) > 1 else 0
        
        # FFT analysis for sleep stage detection
        try:
            fft_vals = np.fft.fft(phase_data)
            freqs = np.fft.fftfreq(len(phase_data))
            magnitude = np.abs(fft_vals)
            
            # Frequency bands
            # Delta waves (0.5-4 Hz) - Deep sleep
            delta_mask = (freqs > 0.5) & (freqs < 4)
            delta_power = np.sum(magnitude[delta_mask] ** 2)
            
            # Theta waves (4-8 Hz) - Light sleep
            theta_mask = (freqs >= 4) & (freqs < 8)
            theta_power = np.sum(magnitude[theta_mask] ** 2)
            
            # Alpha waves (8-12 Hz) - Relaxed
            alpha_mask = (freqs >= 8) & (freqs < 12)
            alpha_power = np.sum(magnitude[alpha_mask] ** 2)
            
            # Beta waves (12-30 Hz) - Awake/REM
            beta_mask = (freqs >= 12) & (freqs < 30)
            beta_power = np.sum(magnitude[beta_mask] ** 2)
            
            total_power = delta_power + theta_power + alpha_power + beta_power
            
            if total_power > 0:
                deep_sleep_percent = (delta_power / total_power) * 100
                rem_sleep_percent = (beta_power / total_power) * 100
            else:
                deep_sleep_percent = 50
                rem_sleep_percent = 50
                
        except:
            deep_sleep_percent = 50
            rem_sleep_percent = 50
        
        # Sleep Duration Score (based on recording length)
        # Assuming 20 samples per second
        samples_per_second = 20
        duration_hours = len(phase_data) / (samples_per_second * 3600)
        sleep_duration_score = min(100, (duration_hours / 8) * 100)
        
        # Sleep Efficiency Score (based on movement)
        sleep_efficiency_score = max(0, min(100, 100 - (movement * 5)))
        
        # Deep Sleep Score
        deep_sleep_score = min(200, deep_sleep_percent * 2)
        
        # REM Sleep Score
        rem_sleep_score = min(200, rem_sleep_percent * 2)
        
        # HRV Score (Heart Rate Variability)
        try:
            # Find peaks in the signal
            from scipy.signal import find_peaks
            normalized = (phase_data - np.mean(phase_data)) / np.std(phase_data)
            peaks, _ = find_peaks(normalized, distance=50, height=0.5)
            
            if len(peaks) > 5:
                # Calculate RR intervals
                rr_intervals = np.diff(peaks)
                hrv = (np.std(rr_intervals) / np.mean(rr_intervals)) * 100
                hrv_score = max(0, min(100, hrv))
            else:
                hrv_score = 50
        except:
            hrv_score = 50
        
        # Return results dictionary
        results = {
            "Sleep Duration Score": f"{sleep_duration_score:.1f}%",
            "Sleep Efficiency Score": f"{sleep_efficiency_score:.1f}%",
            "Deep Sleep Score": f"{deep_sleep_score:.1f}%",
            "REM Sleep Score": f"{rem_sleep_score:.1f}%",
            "HRV Score": f"{hrv_score:.1f}%"
        }
        
        return results
        
    def start_recording(self):
        """Start the radar recording"""
        duration = self.duration_var.get()
        if duration <= 0:
            messagebox.showerror("Invalid Duration", "Duration must be greater than 0 seconds.")
            return
            
        port = self.port_var.get().strip()
        if not port:
            messagebox.showerror("Invalid Port", "Please specify a serial port.")
            return
            
        output_path = self.output_path_var.get().strip()
        if not output_path:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = os.path.abspath(f"radar_data_{timestamp}.csv")
            self.output_path_var.set(output_path)
            
        if os.path.exists(output_path):
            if not messagebox.askyesno("File Exists", f"{output_path} already exists. Overwrite?"):
                return
                
        self.data_buffer = []
        self.progress_var.set(0)
        self.info_text.delete(1.0, tk.END)
        self.info_text.insert(tk.END, f"Recording started at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        self.info_text.insert(tk.END, f"Output file: {output_path}\n")
        self.info_text.insert(tk.END, f"Duration: {duration} seconds\n")
        self.info_text.insert(tk.END, f"Serial port: {port}\n\n")
        self.info_text.insert(tk.END, "Recording in progress...\n")
        
        self.recording = True
        self.stop_event = threading.Event()
        
        self.start_button.config(state="disabled")
        self.stop_button.config(state="normal")
        
        self.ax.cla()
        self.ax.set_xlabel("Time (s)")
        self.ax.set_ylabel("Phase (mm)")
        self.ax.set_title("Real-time Phase Data")
        self.ax.grid(True, alpha=0.3)
        self.line, = self.ax.plot([], [], 'b-', linewidth=1)
        self.ax.set_xlim(0, min(10, duration))
        self.ax.set_ylim(-5, 5)
        self.canvas.draw()
        
        self.record_thread = threading.Thread(
            target=self.start_recording_thread,
            args=(duration, output_path, port),
            daemon=True
        )
        self.record_thread.start()
        self.update_plot()
        self.status_var.set(f"Recording started. Duration: {duration} seconds")
        
    def stop_recording(self):
        """Stop the recording manually"""
        if self.recording and self.stop_event:
            self.stop_event.set()
            self.status_var.set("Stopping recording...")
            self.info_text.insert(tk.END, "\nStopping recording...\n")
            
    def recording_completed(self, output_path):
        """Handle normal recording completion"""
        self.recording = False
        self.current_output_path = output_path
        
        self.start_button.config(state="normal")
        self.stop_button.config(state="disabled")
        
        self.status_var.set(f"Recording completed! Data saved to {output_path}")
        self.progress_var.set(100)
        
        self.info_text.insert(tk.END, f"\n--- Recording Completed ---\n")
        self.info_text.insert(tk.END, f"Data saved to: {output_path}\n")
        self.info_text.insert(tk.END, f"Total samples: {len(self.data_buffer)}\n")
        
        if self.data_buffer:
            values = [v for _, v in self.data_buffer]
            self.info_text.insert(tk.END, f"Mean value: {np.mean(values):.3f} mm\n")
            self.info_text.insert(tk.END, f"Std deviation: {np.std(values):.3f} mm\n")
        
        # Automatically process the data
        self.process_recorded_data(output_path)
        
        messagebox.showinfo("Recording Complete", f"Data has been saved to:\n{output_path}\n\nProcessing has started automatically.")
        
    def recording_stopped(self, output_path):
        """Handle manual stop of recording"""
        self.recording = False
        self.current_output_path = output_path
        
        self.start_button.config(state="normal")
        self.stop_button.config(state="disabled")
        
        self.status_var.set(f"Recording stopped manually. Data saved to {output_path}")
        
        self.info_text.insert(tk.END, f"\n--- Recording Stopped Manually ---\n")
        self.info_text.insert(tk.END, f"Data saved to: {output_path}\n")
        self.info_text.insert(tk.END, f"Total samples: {len(self.data_buffer)}\n")
        
        # Ask if user wants to process
        if messagebox.askyesno("Process Data", "Do you want to process the recorded data?"):
            self.process_recorded_data(output_path)
        
    def recording_error(self, error_message):
        """Handle recording error"""
        self.recording = False
        
        self.start_button.config(state="normal")
        self.stop_button.config(state="disabled")
        
        self.status_var.set(f"Error: {error_message}")
        self.info_text.insert(tk.END, f"\n--- ERROR ---\n{error_message}\n")
        
        messagebox.showerror("Recording Error", f"An error occurred during recording:\n{error_message}")
        
    def process_recorded_data(self, csv_file_path):
        """Process the recorded data and display results"""
        self.status_var.set("Processing data...")
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, f"Processing data from: {csv_file_path}\n\n")
        
        # Run processing in a separate thread
        self.processing_thread = threading.Thread(
            target=self.process_data_thread,
            args=(csv_file_path,),
            daemon=True
        )
        self.processing_thread.start()
        
    def process_data_thread(self, csv_file_path):
        """Process data in a separate thread"""
        # Process the CSV file directly
        results = self.process_csv_directly(csv_file_path)
        
        if results:
            self.root.after(0, self.display_processing_results, results)
        else:
            self.root.after(0, self.processing_error, "Failed to process data")
            
    def display_processing_results(self, results):
        """Display the processing results"""
        self.display_scores(results)
        self.status_var.set("Data processing completed")
        self.output_text.insert(tk.END, "\n✓ Processing completed successfully!\n")
        self.output_text.see(tk.END)
        
    def processing_error(self, error_msg):
        """Handle processing error"""
        self.status_var.set(f"Processing error: {error_msg}")
        self.output_text.insert(tk.END, f"\n✗ Error: {error_msg}\n")
        messagebox.showerror("Processing Error", error_msg)
        
    def process_last_recording(self):
        """Process the last recorded data file"""
        if self.current_output_path and os.path.exists(self.current_output_path):
            self.process_recorded_data(self.current_output_path)
        else:
            filename = filedialog.askopenfilename(
                title="Select CSV file to process",
                filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
            )
            if filename:
                self.process_recorded_data(filename)
            else:
                messagebox.showwarning("No File Selected", "Please select a CSV file to process.")
        
    def on_closing(self):
        """Handle window closing"""
        if self.recording:
            if messagebox.askyesno("Recording in Progress", "Recording is still in progress. Stop and exit?"):
                if self.stop_event:
                    self.stop_event.set()
                self.root.after(500, self.root.destroy)
        else:
            self.root.destroy()


def main():
    root = tk.Tk()
    app = RadarGUI(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()


if __name__ == "__main__":
    main()